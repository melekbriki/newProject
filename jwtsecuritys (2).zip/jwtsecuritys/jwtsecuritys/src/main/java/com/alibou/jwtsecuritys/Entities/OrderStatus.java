package com.alibou.jwtsecuritys.Entities;

public enum OrderStatus {
    Pending,
    Placed,
    Shipped,
    Delivered
}
