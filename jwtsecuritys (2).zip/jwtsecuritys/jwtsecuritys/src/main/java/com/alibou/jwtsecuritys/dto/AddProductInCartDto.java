package com.alibou.jwtsecuritys.dto;


import com.alibou.jwtsecuritys.Entities.User;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class AddProductInCartDto {

    private Integer userId;
    private Long productId;




}
