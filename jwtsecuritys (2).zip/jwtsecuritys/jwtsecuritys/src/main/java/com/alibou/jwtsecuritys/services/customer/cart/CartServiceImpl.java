package com.alibou.jwtsecuritys.services.customer.cart;

import com.alibou.jwtsecuritys.Entities.*;
import com.alibou.jwtsecuritys.Repository.CartItemsRepository;
import com.alibou.jwtsecuritys.Repository.OrderRepository;
import com.alibou.jwtsecuritys.Repository.ProductRepository;
import com.alibou.jwtsecuritys.Repository.UserRepository;
import com.alibou.jwtsecuritys.dto.AddProductInCartDto;
import com.alibou.jwtsecuritys.dto.CartItemsDto;
import com.alibou.jwtsecuritys.dto.OrderDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CartServiceImpl implements CartService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final CartItemsRepository cartItemsRepository;
    private final ProductRepository productRepository;


    public ResponseEntity<?> addProductToCart(AddProductInCartDto addProductInCartDto) {
        // Check if there is an active order for the user
        Order activeOrder = orderRepository.findByUserIdAndOrderStatus(addProductInCartDto.getUserId(), OrderStatus.Pending);

        if (activeOrder == null) {
            // If no active order found, create a new one
            activeOrder = new Order();
            User user = userRepository.getById(addProductInCartDto.getUserId());
            activeOrder.setUser(user);
            activeOrder.setOrderStatus(OrderStatus.Pending);
            activeOrder.setAmount(0L);
            activeOrder.setTotalAmount(0L);
            activeOrder.setDiscount(0L);
            activeOrder.setCartItems(new ArrayList<>());
            activeOrder = orderRepository.save(activeOrder);
        }


        // Check if the product is already in the cart
        Optional<CartItems> optionalCartItems = cartItemsRepository.findByProductIdAndOrderIdAndUserId(
                addProductInCartDto.getProductId(), activeOrder.getId(), addProductInCartDto.getUserId());

        if (optionalCartItems.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(null);
        }

        Optional<Product> optionalProduct = productRepository.findById(addProductInCartDto.getProductId());
        Optional<User> optionalUser = userRepository.findById(addProductInCartDto.getUserId());

        if (optionalProduct.isPresent() && optionalUser.isPresent()) {
            CartItems cart = new CartItems();
            cart.setProduct(optionalProduct.get());
            cart.setPrice(optionalProduct.get().getPrice());
            cart.setQuantity(1L);
            cart.setUser(optionalUser.get());
            cart.setOrder(activeOrder);
            CartItems updatedCart = cartItemsRepository.save(cart);

            // Update order total amount
            activeOrder.setTotalAmount(activeOrder.getTotalAmount() + cart.getPrice());
            activeOrder.setAmount(activeOrder.getAmount() + cart.getPrice());
            activeOrder.getCartItems().add(cart);
            orderRepository.save(activeOrder);

            return ResponseEntity.status(HttpStatus.CREATED).body(cart);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User or product not found");
        }
    }
   public OrderDto getCartByUserId(Integer userId){
       Order activeOrder = orderRepository.findByUserIdAndOrderStatus(userId, OrderStatus.Pending);
       List<CartItemsDto> cartItemsDtoList = activeOrder.getCartItems().stream().map(CartItems::getCartDto).collect(Collectors.toList());
       OrderDto orderDto = new OrderDto();
       orderDto.setAmount(activeOrder.getAmount());
       orderDto.setId(activeOrder.getId());
       orderDto.setOrderStatus(activeOrder.getOrderStatus());
       orderDto.setDiscount(activeOrder.getDiscount());
       orderDto.setTotalAmount(activeOrder.getTotalAmount());
       orderDto.setCartItems(cartItemsDtoList);

       return orderDto;

   }
}
