package com.alibou.jwtsecuritys.services.customer.cart;

import com.alibou.jwtsecuritys.dto.AddProductInCartDto;
import com.alibou.jwtsecuritys.dto.OrderDto;
import org.springframework.http.ResponseEntity;

public interface CartService {

    public ResponseEntity<?> addProductToCart(AddProductInCartDto addProductInCartDto);
    OrderDto getCartByUserId(Integer userId);
}
