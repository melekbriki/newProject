package com.alibou.jwtsecuritys.Entities;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Entity
@Data
@Table(name="orders")
public class Order {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String orderDescription;
    private Date date;

    //montant
    private Long amount;

    private String address;

    private String payement;

    private OrderStatus orderStatus;

    private Long totalAmount;


    private Long discount;

    private UUID trackingId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private User user;


    //ekher haja zedetha
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "order")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private List<CartItems> cartItems;


}
