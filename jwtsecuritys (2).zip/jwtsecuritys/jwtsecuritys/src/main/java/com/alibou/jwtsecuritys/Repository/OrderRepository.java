package com.alibou.jwtsecuritys.Repository;


import com.alibou.jwtsecuritys.Entities.Order;
import com.alibou.jwtsecuritys.Entities.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    Order findByUserIdAndOrderStatus(Integer userId, OrderStatus orderStatus);
}
