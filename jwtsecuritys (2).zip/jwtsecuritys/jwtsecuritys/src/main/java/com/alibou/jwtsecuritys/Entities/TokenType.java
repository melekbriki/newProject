package com.alibou.jwtsecuritys.Entities;

public enum TokenType {
    BEARER
}
