package com.alibou.jwtsecuritys.dto;


import com.alibou.jwtsecuritys.Entities.CartItems;
import com.alibou.jwtsecuritys.Entities.OrderStatus;
import com.alibou.jwtsecuritys.Entities.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Data
public class OrderDto {

    private Long id;

    private String orderDescription;
    private Date date;

    //montant
    private Long amount;

    private String address;

    private String payement;

    private OrderStatus orderStatus;

    private Long totalAmount;


    private Long discount;

    private UUID trackingId;


    private String userName;


    //ekher haja zedetha
  //  @OneToMany
   private List<CartItemsDto> cartItems;


}
