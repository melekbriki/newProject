package com.alibou.jwtsecuritys.services.customer;

import com.alibou.jwtsecuritys.dto.AddProductInCartDto;
import com.alibou.jwtsecuritys.dto.OrderDto;
import com.alibou.jwtsecuritys.services.customer.cart.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;

    @PostMapping("/cartItem")
    public ResponseEntity<?> addProductToCart(@RequestBody AddProductInCartDto addProductInCartDto) {
        return cartService.addProductToCart(addProductInCartDto);
    }


    @GetMapping("/cartItem/{userId}")
    public ResponseEntity<?> getCartByUserId(@PathVariable Integer userId) {
        OrderDto orderDto = cartService.getCartByUserId(userId);
        return ResponseEntity.status(HttpStatus.OK).body(orderDto);
    }
}