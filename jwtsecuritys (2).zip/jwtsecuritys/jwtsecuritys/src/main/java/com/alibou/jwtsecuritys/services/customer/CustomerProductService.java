package com.alibou.jwtsecuritys.services.customer;

import com.alibou.jwtsecuritys.dto.ProductDto;

import java.util.List;

public interface CustomerProductService {



    public List<ProductDto> searchProductByTitle(String title);
    public List<ProductDto> getAllProducts();
}
